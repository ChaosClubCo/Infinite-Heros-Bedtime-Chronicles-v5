import OpenAI from "openai";
import type { AIProvider, TextGenerationRequest, TextGenerationResponse, ImageGenerationRequest, ImageGenerationResponse, StreamingTextChunk } from "../types";
import { CHECK_TIMEOUT_MS } from "../../health-checks";

export async function pingOpenAI(): Promise<boolean> {
  // Mirror the client selection in generateText (getIntegrationsClient →
  // getDirectClient): the integrations key uses its base URL, but the direct
  // OPENAI_API_KEY always targets api.openai.com. Pairing the direct key with a
  // stray AI_INTEGRATIONS_OPENAI_BASE_URL would probe the wrong host and report
  // a false outage.
  const integrationsKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const directKey = process.env.OPENAI_API_KEY;
  let apiKey: string;
  let baseURL: string;
  if (integrationsKey) {
    apiKey = integrationsKey;
    baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || "https://api.openai.com/v1";
  } else if (directKey) {
    apiKey = directKey;
    baseURL = "https://api.openai.com/v1";
  } else {
    return false;
  }
  try {
    const res = await fetch(`${baseURL}/models`, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(CHECK_TIMEOUT_MS),
    });
    return res.ok;
  } catch {
    return false;
  }
}

function getIntegrationsClient(): OpenAI | null {
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  if (!apiKey) return null;
  return new OpenAI({ apiKey, baseURL: baseURL || undefined });
}

function getDirectClient(): OpenAI | null {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  return new OpenAI({ apiKey });
}

export const openaiProvider: AIProvider = {
  name: "openai",
  displayName: "OpenAI",
  textModel: "gpt-4o-mini",
  capabilities: { text: true, image: true, streaming: true },

  isAvailable(): boolean {
    return !!(
      process.env.AI_INTEGRATIONS_OPENAI_API_KEY ||
      process.env.OPENAI_API_KEY
    );
  },

  async generateText(req: TextGenerationRequest): Promise<TextGenerationResponse> {
    const client = getIntegrationsClient() || getDirectClient();
    if (!client) throw new Error("OpenAI not configured");

    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: "system", content: req.systemPrompt },
      { role: "user", content: req.userPrompt },
    ];

    const params: OpenAI.Chat.Completions.ChatCompletionCreateParamsNonStreaming = {
      model: "gpt-4o-mini",
      messages,
      temperature: req.temperature ?? 0.9,
      max_tokens: req.maxTokens ?? 8192,
    };

    if (req.jsonMode) {
      params.response_format = { type: "json_object" };
    }

    const response = await client.chat.completions.create(params);
    const text = response.choices[0]?.message?.content || "";

    return {
      text,
      provider: "openai",
      model: "gpt-4o-mini",
      usage: {
        inputTokens: response.usage?.prompt_tokens,
        outputTokens: response.usage?.completion_tokens,
      },
    };
  },

  async *generateTextStream(req: TextGenerationRequest): AsyncGenerator<StreamingTextChunk> {
    const client = getIntegrationsClient() || getDirectClient();
    if (!client) throw new Error("OpenAI not configured");

    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: "system", content: req.systemPrompt },
      { role: "user", content: req.userPrompt },
    ];

    const stream = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      temperature: req.temperature ?? 0.9,
      max_tokens: req.maxTokens ?? 8192,
      stream: true,
    });

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        yield { text: content, done: false };
      }
    }
    yield { text: "", done: true };
  },

  async generateImage(req: ImageGenerationRequest): Promise<ImageGenerationResponse> {
    const client = getDirectClient() || getIntegrationsClient();
    if (!client) throw new Error("OpenAI not configured for image generation");

    const response = await client.images.generate({
      model: "gpt-image-1",
      prompt: req.prompt,
      size: (req.size as "1536x1024") || "1536x1024",
      quality: (req.quality as "low") || "low",
      n: 1,
    });

    const imageData = response.data?.[0];
    if (!imageData) throw new Error("OpenAI returned no image data");

    const imageRecord = imageData as Record<string, unknown>;
    if (imageRecord.b64_json) {
      return {
        imageDataUri: `data:image/png;base64,${imageRecord.b64_json}`,
        provider: "openai",
        model: "gpt-image-1",
      };
    }
    if (imageData.url) {
      return {
        imageDataUri: imageData.url,
        provider: "openai",
        model: "gpt-image-1",
      };
    }
    throw new Error("OpenAI returned no usable image");
  },
};
